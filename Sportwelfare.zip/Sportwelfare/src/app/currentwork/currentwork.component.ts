import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-currentwork',
  templateUrl: './currentwork.component.html',
  styleUrls: ['./currentwork.component.css']
})
export class CurrentworkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
